#pragma once
#ifndef NEIGE_H
#define NEIGE_H

/**
 * Compiles the main source file by assigning each word to a specific token
 * @param source the content of the source file represented in string
 */
void neige_compile (char *source);

#endif